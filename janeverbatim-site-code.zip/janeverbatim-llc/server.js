import { createServer as createHttpServer } from "node:http";
import {
  existsSync,
  lstatSync,
  mkdirSync,
  readFileSync,
  symlinkSync,
} from "node:fs";
import { resolve } from "node:path";
import express from "/usr/local/lib/node_modules/express/index.js";
import compression from "/usr/local/lib/node_modules/compression/index.js";
import { createServer as createViteServer } from "/usr/local/lib/node_modules/vite/dist/node/index.js";
import { APP_BASE_URL } from "/usr/lib/sfs-assistant-dev/platform-config.js";

const GLOBAL_NODE_MODULES = "/usr/local/lib/node_modules";

// Packages that EVERY project must be able to resolve from its own node_modules,
// regardless of skeleton age. @vitejs/plugin-react@4 externalises react-refresh
// and Vite resolves it relative to the project (via the bundled temp config),
// not the plugin's global location — so without this, every site (new AND
// pre-existing, v3 and v4) fails with "Cannot find package 'react-refresh'".
// These are ensured unconditionally; the per-project `.platform-deps` manifest
// adds any extra framework runtimes (e.g. svelte/preact).
const ALWAYS_LINK = ["react-refresh"];

// Symlink node_modules/<pkg> -> /usr/local/lib/node_modules/<pkg> for each
// required package. Done at startup (not baked into the skeleton) so it survives
// node_modules being an empty/tmpfs mount and works for sites created before
// this mechanism existed. Idempotent and best-effort.
function ensurePlatformDeps() {
  const root = process.cwd();
  const nodeModules = resolve(root, "node_modules");
  const pkgs = [...ALWAYS_LINK];
  const manifest = resolve(root, ".platform-deps");
  if (existsSync(manifest)) {
    for (const raw of readFileSync(manifest, "utf-8").split("\n")) {
      const p = raw.trim();
      if (p && !p.startsWith("#") && !pkgs.includes(p)) pkgs.push(p);
    }
  }
  for (const pkg of pkgs) {
    const link = resolve(nodeModules, pkg);
    try {
      if (existsSync(link) || lstatSync(link, { throwIfNoEntry: false })) continue;
      mkdirSync(resolve(link, ".."), { recursive: true });
      symlinkSync(`${GLOBAL_NODE_MODULES}/${pkg}`, link);
      console.log(`[platform-deps] linked node_modules/${pkg}`);
    } catch (err) {
      console.warn(`[platform-deps] could not link ${pkg}: ${err.message}`);
    }
  }
}

async function startServer() {
  ensurePlatformDeps();

  const app = express();
  // Gzip all dev responses. The dev server serves UNCOMPRESSED native-ESM
  // modules; over a remote link (and unbundled, so ~8 MB of JS for a small app:
  // react-dom ~1 MB, react-router ~0.5 MB, the lucide bundle, app modules) a
  // cacheless browser load was transfer-bound (~14 s). gzip cuts the JS/CSS
  // payload ~5x and is the single biggest win for warm cacheless loads.
  app.use(compression());
  const server = createHttpServer(app);

  // Initialize Vite server.
  // NOTE: configLoader:"runner" was tried to keep the project node_modules empty
  // (so @vitejs/plugin-react@4 resolves its external react-refresh from the
  // global install instead of the bundled temp config). It is incompatible with
  // middlewareMode — the config-loading module runner is closed before the
  // react-babel transform runs ("Vite module runner has been closed"). Instead
  // the skeleton ships a node_modules/react-refresh symlink to the global copy.
  const vite = await createViteServer({
    server: {
      middlewareMode: true,
      hmr: { server },
      overlay: false,
      allowedHosts: true,
      watch: {
        interval: 300,
        ignored: [
          '**/node_modules/**',
          '**/.git/**',
          '**/dist/**'
        ]
      }
    },
  });

  // 2. Add wide-open CORS headers before any other middleware
  app.use((req, res, next) => {
    const origin = req.headers.origin || "*";
    res.setHeader("Access-Control-Allow-Origin", origin);
    res.setHeader("Access-Control-Allow-Methods", "*");
    res.setHeader("Access-Control-Allow-Headers", "*");
    res.setHeader("Access-Control-Allow-Credentials", "true");
    if (req.method === "OPTIONS") return res.sendStatus(204);
    next();
  });

  // 3. Use vite's connect instance as middleware (dynamically proxy to current vite instance)
  app.use((req, res, next) => {
    if (vite && vite.middlewares) {
      vite.middlewares(req, res, next);
    } else {
      // Vite is temporarily unavailable during a config reload
      res.status(503).send("Server reloading, please retry");
    }
  });

  // 4. Use prependListener to ensure this runs BEFORE Vite's internal HMR listener
  server.prependListener("upgrade", (req) => {
    const isViteHMR =
      req.url?.includes("token=") &&
      req.headers["upgrade"]?.toLowerCase() === "websocket";

    if (isViteHMR && !req.url.startsWith(APP_BASE_URL)) {
      // Perform the rewrite
      const separator = req.url.startsWith("/") ? "" : "/";
      req.url = `${APP_BASE_URL.slice(0, -1)}${separator}${req.url}`;
    }
  });

  // 5. Start the server on the socket passed as fd 0 by the parent process
  server.listen({ fd: 0 }, () => {
    console.log(`--- Server Ready ---`);
  });
}

startServer().catch((error) => {
  console.error(error);
  process.exit(1);
});
